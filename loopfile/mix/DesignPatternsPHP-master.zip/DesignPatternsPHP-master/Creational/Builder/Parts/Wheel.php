<?php

namespace DesignPatterns\Creational\Builder\Parts;

class Wheel
{
}
