<?php

namespace DesignPatterns\Creational\AbstractFactory;

class JsonText extends Text
{
    // do something here
}
