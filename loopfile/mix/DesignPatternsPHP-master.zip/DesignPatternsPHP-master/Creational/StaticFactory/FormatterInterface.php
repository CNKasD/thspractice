<?php

namespace DesignPatterns\Creational\StaticFactory;

interface FormatterInterface
{
}
